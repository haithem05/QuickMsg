package com.example.quickmsg;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class SignUpActivity extends AppCompatActivity {
    private EditText email, password,confirm;
    private Button signUpBtn;
    private TextView alreadyHaveAccount;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        initializeFields();

        alreadyHaveAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendUserToLogin();
            }
        });
    }

















    private void sendUserToLogin() {
        Intent loginIntent=new Intent(SignUpActivity.this,LoginActivity.class);
        startActivity(loginIntent);
    }


    private void initializeFields() {

        signUpBtn= (Button) findViewById(R.id.signup_btn);
        email = (EditText) findViewById(R.id.emaill) ;
        password = (EditText) findViewById(R.id.passwordd);
        alreadyHaveAccount = (TextView) findViewById(R.id.already_have_acount);
        confirm = (EditText) findViewById(R.id.confirm);

    }

}


