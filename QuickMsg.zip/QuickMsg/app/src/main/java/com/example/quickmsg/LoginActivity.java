package com.example.quickmsg;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TextView;
import android.support.design.widget.TableLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;




public class LoginActivity extends AppCompatActivity {
    private Button login ;
    private EditText email , password ;
    private TextView needNewAcount;
    private Toolbar ktoolbar;
    private ViewPager myViewPager;
    private TableLayout myTabLayout;
private TabsAccesessorAdapter myTabsAccesessorAdapter ;



    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        myTabsAccesessorAdapter = new TabsAccesessorAdapter(getSupportFragmentManager()) ;
        myViewPager.setAdapter(myTabsAccesessorAdapter);
        TableLayout tabLayout = myTabLayout = (TableLayout) findViewById(R.id.tab_layout);
        tabLayout.setupWithViewPager(myViewPager);
        initializeFields();

        needNewAcount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                sendUserToSignup();

            }
        });


    }











































    private void sendUserToSignup() {
        Intent signUpIntent=new Intent(LoginActivity.this,SignUpActivity.class);
        startActivity(signUpIntent);
    }


    private void initializeFields() {

        login= (Button) findViewById(R.id.login_btn);
        email = (EditText) findViewById(R.id.email) ;
        password = (EditText) findViewById(R.id.password);
        needNewAcount = (TextView) findViewById(R.id.need_new_account_link);
        ktoolbar=(Toolbar) findViewById( R.id.app_toolbar);
        myViewPager = (ViewPager) findViewById(R.id.tab_pager);

        setSupportActionBar(ktoolbar);
        setTitle("QuickMsg");


    }


}
